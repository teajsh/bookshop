document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('book-form');
    const bookList = document.getElementById('book-list');

    async function fetchBooks() {
        try {
            const response = await fetch('http://localhost:5000/api/books');
            const books = await response.json();
            renderBooks(books);
        } catch (error) {
            console.error('Error fetching books:', error);
        }
    }

    async function addBook(title, author, price) {
        try {
            const response = await fetch('http://localhost:5000/api/books', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ title, author, price })
            });
            const newBook = await response.json();
            fetchBooks();
        } catch (error) {
            console.error('Error adding book:', error);
        }
    }

    async function deleteBook(id) {
        try {
            await fetch(`http://localhost:5000/api/books/${id}`, {
                method: 'DELETE'
            });
            fetchBooks();
        } catch (error) {
            console.error('Error deleting book:', error);
        }
    }

    async function editBook(id, title, author, price) {
        try {
            await fetch(`http://localhost:5000/api/books/${id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ title, author, price })
            });
            fetchBooks();
        } catch (error) {
            console.error('Error updating book:', error);
        }
    }

    function renderBooks(books) {
        bookList.innerHTML = '';
        books.forEach(book => {
            const li = document.createElement('li');
            li.innerHTML = `
                <strong>${book.title}</strong><br>
                Author: ${book.author}<br>
                Price: $${book.price.toFixed(2)}
                <button class="delete-button" data-id="${book._id}">Delete</button>
                <button class="edit-button" data-id="${book._id}">Edit</button>
            `;
            bookList.appendChild(li);
        });
    }

    form.addEventListener('submit', (e) => {
        e.preventDefault();
        const title = document.getElementById('title').value;
        const author = document.getElementById('author').value;
        const price = parseFloat(document.getElementById('price').value);
        if (title && author && !isNaN(price)) {
            addBook(title, author, price);
            form.reset();
        }
    });

    bookList.addEventListener('click', (e) => {
        if (e.target.classList.contains('delete-button')) {
            const id = e.target.getAttribute('data-id');
            deleteBook(id);
        } else if (e.target.classList.contains('edit-button')) {
            const id = e.target.getAttribute('data-id');
            const title = prompt('Enter new title:');
            const author = prompt('Enter new author:');
            const price = parseFloat(prompt('Enter new price:'));
            if (title && author && !isNaN(price)) {
                editBook(id, title, author, price);
            }
        }
    });

    fetchBooks();
});
