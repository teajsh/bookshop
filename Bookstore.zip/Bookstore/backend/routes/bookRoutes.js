const express = require('express');
const router = express.Router();
const Book = require('../models/Book');

// Get all books
router.get('/books', async (req, res) => {
    try {
        const books = await Book.find();
        res.json(books);
    } catch (err) {
        res.status(500).json({ message: 'Error fetching books', error: err });
    }
});

// Add a new book
router.post('/books', async (req, res) => {
    const { title, author, price } = req.body;
    try {
        const newBook = new Book({ title, author, price });
        await newBook.save();
        res.status(201).json(newBook);
    } catch (err) {
        res.status(400).json({ message: 'Error adding book', error: err });
    }
});

// Update a book
router.put('/books/:id', async (req, res) => {
    try {
        const updatedBook = await Book.findByIdAndUpdate(req.params.id, req.body, { new: true });
        res.json(updatedBook);
    } catch (err) {
        res.status(400).json({ message: 'Error updating book', error: err });
    }
});

// Delete a book
router.delete('/books/:id', async (req, res) => {
    try {
        await Book.findByIdAndDelete(req.params.id);
        res.json({ message: 'Book deleted' });
    } catch (err) {
        res.status(400).json({ message: 'Error deleting book', error: err });
    }
});

module.exports = router;
