module.exports = {
    mongoURI: 'mongodb://localhost:27017/bookstore' // Replace with your MongoDB URI if needed
};
